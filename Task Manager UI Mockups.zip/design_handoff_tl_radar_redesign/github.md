repo: FLAIR-soft/TL-Radar
branch: claude/tl-radar-nextjs-setup-g0kqyc

## Last sync
date: 2026-08-03T06:22:00Z

### Updated in this project
- Added turn 4: the remaining five tabs from `TopTabs.tsx` — Archiv, Projekte, Vorlagen, Analytik, Admin.
- Archive table row composition verified against `archive/page.tsx`: status pill + icon + labels + assignees in the task cell, pause→resume pairs in the Pausen cell, "Verspätet um" under Abgeschlossen, detail button as last column.
- Analytics reproduces all three blocks of `analytics/page.tsx` (person bars, cumulative flow, estimate accuracy).
- Admin shows WIP limits form and user rows with reset/delete actions.

## Sync history
### 2026-08-02T22:09:11Z
- Added turn 3: detail-rich task cards, task detail slide-over and the "Neue Aufgabe" form.
- Slide-over content mirrors `TaskDetailPanel.tsx`, `ChecklistList.tsx`, `CommentList.tsx`.
- Form fields and order follow `dashboard/new/TaskForm.tsx`.

## Screen map
| Project screen | Repo files |
| --- | --- |
| TL-Radar Redesign.dc.html — 2a / 2b (Task-Manager board, light + dark) | app/globals.css, app/(app)/layout.tsx, app/(app)/TopTabs.tsx, app/(app)/dashboard/page.tsx, app/(app)/dashboard/KanbanBoard.tsx, app/(app)/dashboard/TaskCard.tsx, components/TaskFilterBar.tsx, lib/i18n/dictionaries/de.ts |
| TL-Radar Redesign.dc.html — 2c (mobile board) | same as above |
| TL-Radar Redesign.dc.html — 3a (task cards, 3 densities) | app/(app)/dashboard/TaskCard.tsx, lib/supabase/types.ts, lib/logic/priority.ts, lib/i18n/dictionaries/de.ts |
| TL-Radar Redesign.dc.html — 3b (task detail slide-over) | app/(app)/dashboard/TaskDetailPanel.tsx, components/SlideOver.tsx, components/ChecklistList.tsx, components/CommentList.tsx, components/ActivityLogList.tsx |
| TL-Radar Redesign.dc.html — 3c (Neue Aufgabe form) | app/(app)/dashboard/new/TaskForm.tsx, components/IconPicker.tsx, components/PrioritySelect.tsx, app/(app)/dashboard/new/AssigneeSelect.tsx, app/(app)/dashboard/new/LabelSelect.tsx |
| TL-Radar Redesign.dc.html — 4a (Archiv) | app/(app)/archive/page.tsx, lib/i18n/dictionaries/de.ts |
| TL-Radar Redesign.dc.html — 4b (Projekte) | app/(app)/projects/page.tsx, app/(app)/projects/ProjectRow.tsx, app/(app)/projects/ProjectForm.tsx |
| TL-Radar Redesign.dc.html — 4c (Vorlagen) | app/(app)/templates/page.tsx, app/(app)/templates/TemplateRow.tsx, app/(app)/templates/RecurringRuleRow.tsx |
| TL-Radar Redesign.dc.html — 4d (Analytik) | app/(app)/analytics/page.tsx, app/(app)/analytics/AnalyticsStats.tsx, components/CumulativeFlowChart.tsx, components/EstimateAccuracyTable.tsx |
| TL-Radar Redesign.dc.html — 4e (Admin) | app/(app)/admin/page.tsx, app/(app)/admin/WipLimitsForm.tsx, app/(app)/admin/ResetPasswordForm.tsx |
| TL-Radar Redesign.dc.html — turn 1 (1a/1b/1c explorations) | built before repo access, from screenshot only |
