# Handoff: TL-Radar — редизайн интерфейса (все вкладки)

## Overview

Пакет содержит визуальный редизайн приложения **TL-Radar** (`FLAIR-soft/TL-Radar`, ветка `claude/tl-radar-nextjs-setup-g0kqyc`) — трекер задач для тимлидов: канбан в реальном времени, таймеры, паузы, аналитика.

Редизайн покрывает все семь вкладок из `app/(app)/TopTabs.tsx`:
Task-Manager, Neue Aufgabe, Archiv, Projekte, Vorlagen, Analytik, Admin — плюс панель задачи (SlideOver), мобильную версию борда и тёмную тему борда.

**Структура данных, роуты, серверные экшены и логика не меняются.** Меняются: шрифт, шкала радиусов и теней, плотность, состав карточки задачи, и подача таблиц/графиков. Почти всё делается в `app/globals.css` — имена классов в макетах намеренно совпадают с существующими (`.tabs`, `.section-title`, `.project-row`, `.archive-table`, `.stat-row`, `.admin-row`, `.pill`, `.icon-btn`, `.t-meta`, `.mono`, `.overdue-badge`).

## About the Design Files

Файлы в пакете — **дизайн-референсы, написанные на HTML**. Это прототипы, показывающие внешний вид и поведение, а **не production-код для копирования**. Задача — воспроизвести эти макеты в существующей среде проекта (Next.js 15 App Router + React + серверные компоненты + Supabase + lucide-react), используя уже принятые в кодовой базе паттерны: серверные компоненты для данных, `'use client'` только там, где нужен стейт, серверные экшены для мутаций, глобальный CSS с CSS-переменными (никакого Tailwind, никаких новых зависимостей).

Открывать `TL-Radar Redesign.dc.html` можно прямо в браузере. Полотно организовано «поворотами» (turns), новые сверху:

- **turn 4** — Archiv (4a), Projekte (4b), Vorlagen (4c), Analytik (4d), Admin (4e)
- **turn 3** — карточки задач в трёх плотностях (3a), панель задачи (3b), форма «Neue Aufgabe» (3c)
- **turn 2** — борд Task-Manager: светлая тема (2a), тёмная (2b), мобильная 390px (2c)
- **turn 1** — три ранние layout-концепции (исторические, можно игнорировать)

## Fidelity

**High-fidelity.** Все цвета, размеры шрифтов, отступы, радиусы и тени — финальные и указаны точными значениями ниже. Верстать пиксель-в-пиксель, иконки — `lucide-react` с `strokeWidth={1.75}` (те же имена иконок, что уже используются в компонентах).

Исключение — turn 1: черновые концепции, не реализовывать.

## Design Tokens

Готовый набор правок лежит в **`tokens.css`** — это дополнение/замена части `app/globals.css`. Значения:

### Шрифты

| Роль | Значение |
| --- | --- |
| UI | `Archivo` (Google Fonts, weights 400/500/600/700), fallback `system-ui, sans-serif` |
| Цифры, таймеры, `@username`, даты | `ui-monospace, Menlo, monospace` + **обязательно** `font-variant-numeric: tabular-nums` |

Подключение — один `<link>` в `app/layout.tsx` (или `next/font/google`), см. `tokens.css`.

### Цвета — светлая тема

| Токен | Hex | Где |
| --- | --- | --- |
| `--brand` | `#e20617` | акценты, просрочка, кнопка «Neue Aufgabe», перегруз в аналитике |
| `--brand-tint` | `#fff7f7` | фон активной вкладки, фон бейджа даты-просрочки |
| `--brand-border` | `#fecaca` | рамка красных бейджей |
| `--brand-ink` | `#c2323c` | текст роли Admin, ссылки при hover |
| `--bg` | `#f5f5f7` | фон страницы |
| `--surface` | `#ffffff` | карточки, строки, шапка |
| `--surface-2` | `#fafafa` | инпуты в покое, шапка таблицы |
| `--surface-3` | `#f4f4f5` | нейтральные пилюли, чипы фильтров |
| `--border` | `#e4e4e7` | основные границы |
| `--border-soft` | `#f2f2f4` | разделители внутри карточек и строк таблицы |
| `--text` | `#18181b` | заголовки, значения |
| `--text-2` | `#55606e` | вторичный текст, мета |
| `--text-3` | `#8b909b` | подписи, плейсхолдеры |
| `--text-4` | `#a0a4ae` | «—», выключенное |

### Цвета — тёмная тема (см. 2b)

`--bg #0c0c0e`, `--surface #131316`, `--surface-2 #19191c`, `--border #232327`, `--border-2 #2e2e33`, `--text #f4f4f5`, `--text-2 #9a9aa2`, `--text-3 #6f6f78`, `--brand #ff3b4e`.

### Статусы (точки в колонках, WIP-лимиты, график потока)

| Статус | Hex | Пилюля (bg / текст) |
| --- | --- | --- |
| `waiting` | `#71717a` | `#f4f4f5` / `#55606e` |
| `in_progress` | `#2563eb` | `#eff6ff` / `#2563eb` |
| `paused` | `#f59e0b` | `#fffbeb` / `#b45309` |
| `done` | `#16a34a` | `#f0fdf4` / `#16a34a` |

У активной точки статуса — ореол: `box-shadow: 0 0 0 4px rgba(37,99,235,.16)` (цвет статуса, alpha .16).

### Приоритеты (левая полоса 3px у карточек, строк проектов и шаблонов)

| Приоритет | Полоса | Пилюля (bg / текст) |
| --- | --- | --- |
| нет | `#e4e4e7` | — («— keine Priorität —», `--text-4`) |
| `low` | `#94a3b8` | `#f4f4f5` / `#55606e` |
| `medium` | `#8b5cf6` | `#eef2ff` / `#4338ca` |
| `high` | `#f59e0b` | `#fff7ed` / `#c2410c` |
| `urgent` | `#e20617` | `#fef2f2` / `#e20617` |

### Радиусы

`4px` бейдж-код · `6px` внутренний сегмент таб-группы · `7–8px` кнопки, инпуты, чипы, иконочные кнопки · `12px` карточки, строки, панели, колонки борда · `999px` пилюли, аватары, полосы прогресса.

### Тени

```css
--shadow-1: 0 1px 2px rgba(0,0,0,.06);                                  /* строки, спокойные карточки */
--shadow-2: 0 2px 4px rgba(0,0,0,.06), 0 12px 24px -8px rgba(24,24,27,.08); /* активная карточка задачи */
--shadow-3: 0 2px 4px rgba(0,0,0,.06), 0 14px 28px -12px rgba(24,24,27,.16); /* строка в режиме редактирования, поповеры */
--shadow-brand: 0 1px 2px rgba(226,6,23,.3), 0 8px 16px -8px rgba(226,6,23,.5); /* только основная красная кнопка */
--shadow-dark: 0 12px 24px -8px rgba(0,0,0,.5);                          /* карточки в тёмной теме */
```

Фокус на инпуте: `border-color: #18181b; box-shadow: 0 0 0 3px rgba(24,24,27,.08)`.

### Отступы и типографика

- Контент страницы: `padding: 26px 24px 34px`, вертикальный `gap: 18px` (аналитика — `22px`).
- Шапка: высота `60px`, `padding: 0 24px`, снизу `1px solid var(--border)`.
- Максимальная ширина: борд/архив/аналитика — во всю ширину; Projekte — `1040px`; Admin — `1080px`; форма задачи — две колонки.
- `h1` (`.section-title`): `24px/700`, `letter-spacing: -.6px`. Подзаголовок (`.section-sub`): `13px`, `--text-2`, отступ сверху `5px`.
- `h3` секции: `16px/700`, `letter-spacing: -.3px`.
- Заголовок карточки задачи: `16px/700`, `letter-spacing: -.35px`, `line-height: 1.3`, `text-wrap: pretty`.
- Заголовок строки проекта/шаблона: `15–16px/700`.
- Тело/мета: `12.5–13px`, `line-height: 1.55`.
- Заголовки таблиц: `10px/600` моно, `letter-spacing: .8px`, `text-transform: uppercase`, `--text-3`.
- Мелкие пилюли: `11px/500`, `padding: 3px 9px`. Статусные капс-бейджи: `10px/600–700`, `letter-spacing: .5px`, uppercase, `padding: 2px 8px`.
- Крупный таймер в карточке: `17–24px/700` моно, `letter-spacing: -.5…-1px`.

## Screens / Views

### 1. Шапка приложения — `app/(app)/layout.tsx`, `TopTabs.tsx`

Одна строка `60px`, `--surface`, снизу граница. Слева: логотип — плитка `28×28`, `radius 8`, `--brand`, внутри белая иконка-«радар» (два круга + луч, `strokeWidth 2.25`); рядом «TL-Radar» `15px/700`, `letter-spacing -.3px`. Дальше вкладки: `gap 2px`, каждая `13px`, `padding 7px 12px`; активная — `font-weight 600`, `radius 8`, фон `--brand-tint`, текст `--brand`; неактивные — `--text-2`, без фона.

Справа, `gap 12px`: поле поиска-заглушка (`width 150`, `radius 8`, `--surface-3`, рамка `--border`, иконка поиска `14px`, текст `12px --text-3`, справа `⌘K` моно `10px`); иконочная кнопка уведомлений `30×30` (`radius 8`, рамка, при непрочитанных — точка `7px` `--brand` с белой обводкой `1.5px` в правом верхнем углу); переключатель темы `30×30`; переключатель языка — три сегмента `DE/EN/RU`, моно `10.5px/600`, `padding 6px 8px`, активный — фон `--text`, белый текст, вся группа в рамке с `radius 8`; затем разделитель `1px` и профиль: аватар-круг `28px` (`--text` фон, белые инициалы `10.5px/700`), имя `12.5px/500`, «Abmelden» `12.5px --text-2`.

Все элементы шапки — на каждом экране идентичны, меняется только активная вкладка.

### 2. Archiv — `4a` — `app/(app)/archive/page.tsx`

Заголовок «Archiv» + подзаголовок из `dict.archive.subtitle`. Справа две кнопки экспорта (`CSV`, `XLSX`) — белые, рамка `--border`, `radius 8`, `padding 9px 14px`, иконка download `14px`.

Панель фильтров (`.filter-bar`): белая, `radius 12`, рамка, `--shadow-1`, `padding 8px`, `gap 8px`; внутри — поле поиска (иконка + плейсхолдер `13px --text-3`), чипы-селекты «Alle Projekte», «Beliebiger Ansprechpartner», период («Juli 2026») — `12.5px`, `padding 7px 12px`, `radius 8`, фон `--surface-3`, chevron-down `13px`; в конце ссылка «Filter zurücksetzen» `12.5px --text-3`.

Таблица (`.archive-table`) — белая карточка `radius 12`, рамка, `overflow: hidden`. Grid из 10 колонок:
`2.2fr .95fr .8fr .9fr .7fr 1.05fr 1.55fr .95fr 1.05fr 34px`, `gap 12px`, ячейки `padding 14px 18px`, `align-items: flex-start`, разделитель строк `1px solid --border-soft`.

Шапка таблицы: фон `--surface-2`, `padding 12px 18px`, подписи из `dict.archive.col*`; «Nettozeit» и «Ist / Schätzung» выровнены вправо, последняя колонка пустая.

Состав строки (точно как в `archive/page.tsx`):
1. **Aufgabe** — колонка: строка с иконкой задачи (`ICON_MAP`, `14–15px`, `--text-3`) и названием `13.5px/600`; ниже ряд: капс-пилюля «Erledigt» (`done`-цвета) + пилюли этикеток в цвете `labels.color` + имена исполнителей моно `11px --text-3` через запятую.
2. **Projekt** — пилюля `--surface-3` или «— kein Projekt —» цветом `--text-4`.
3. **Ort** — текст `12.5px --text-2`, «—» если пусто.
4. **Erfasst / Gestartet / Abgeschlossen** — моно `12px`, `tabular-nums` (в макете дата+время для «Erfasst», время для остальных). Если задача завершена позже дедлайна, **в ячейке «Abgeschlossen»** под временем — бейдж `Verspätet um <duration>`: `10px/600` uppercase, `letter-spacing .4px`, `padding 2px 7px`, `radius 999`, фон `#fef2f2`, рамка `--brand-border`, текст `--brand`.
5. **Pausen** — колонка из строк «⏸ 10:30 → ▶ 10:45» (иконки `Pause`/`Play` `11px`, `--text-4`; стрелка `#c9ccd2`), моно `11px`; если пауз нет — «—» цветом `--text-4`.
6. **Nettozeit** — моно `13px/700`, `--text`, вправо.
7. **Ist / Schätzung** — моно `12px/600`, вправо: зелёный `#16a34a`, если ≤ оценки, `--brand`, если превышена, `--text-4` для «— / —».
8. Последняя колонка — иконочная кнопка `26×26` (`radius 7`, рамка, chevron-right `14px`), открывает `TaskDetailPanel`.

Под таблицей: «6 von 128 abgeschlossenen Aufgaben» `12.5px --text-3` слева, пагинация справа (активная страница — тёмная плитка `radius 8`, остальные белые в рамке, моно `12px`).

Пустые состояния берутся из `EmptyState`: `dict.archive.empty` / `emptyTitle`, при активных фильтрах — `dict.filters.noResults*` с кнопкой сброса.

### 3. Projekte — `4b` — `projects/page.tsx`, `ProjectRow.tsx`, `ProjectForm.tsx`

Контент ограничен `1040px`. Заголовок + подзаголовок слева, справа основная красная кнопка «Projekt hinzufügen» (`13px/600`, `padding 9px 16px`, `radius 8`, `--brand`, `--shadow-brand`, иконка plus `15px`, `strokeWidth 2`).

Строка проекта (`.project-row`): белая, `radius 12`, рамка, `--shadow-1`, слева полоса `3px` цвета приоритета, `padding 16px 18px`, вертикальный `gap 9px`.
- Первая строка: иконка проекта `16px` + имя `16px/700`; справа группа: пилюля приоритета, пилюля «N Aufgaben» (моно `11.5px/600`, `--surface-3`), три иконочные кнопки `30×30` (`Pencil`, `Trash2`, `ChevronRight` → `ProjectDetailPanel`).
- Описание: `13px`, `line-height 1.55`, `--text-2`, `text-wrap: pretty`.
- Мета (`.t-meta`): `12px --text-2`, `gap 16px`, иконки `MapPin` (локация) и `User` (ответственный) по `14px`; «— nicht zugewiesen —» цветом `--text-4`.

Режим редактирования (`ProjectForm` вместо строки): карточка без цветной полосы, рамка `#d4d4d8`, `--shadow-3`, `padding 18px`, `gap 14px`. Сверху подпись-эйбрау «Projekt bearbeiten» (моно `10px/600`, uppercase, `letter-spacing 1px`, иконка `Pencil` `13px`). Поля: две колонки — «Projektname» (в фокусе) и «Ort»; ниже «Beschreibung» на всю ширину (`min-height 44px`); ниже три колонки — «Verantwortlich» (select), «Priorität» (select с цветной точкой `8px`), «Symbol» (`IconPicker`: плитки `34×34`, `radius 8`, выбранная — фон `--text`, белая иконка). Внизу: «Speichern» (тёмная кнопка `--text`, `13px/600`, `padding 9px 16px`) и «Abbrechen» (текстовая, `--text-2`). Лейблы полей — `12px/600 --text`, инпуты `13.5px`, `padding 10px 12px`, `radius 8`, фон `--surface-2`, рамка `--border`.

### 4. Vorlagen — `4c` — `templates/page.tsx`, `TemplateRow.tsx`, `RecurringRuleRow.tsx`

Две равные колонки, `gap 28px`. Слева «Vorlagen» + список шаблонов, справа «Wiederkehrende Regeln» + кнопка «Regel hinzufügen» (белая, рамка `#d4d4d8`, `13px/600`) и список правил.

Строка шаблона — как строка проекта, но: заголовок `15px/700`, `padding 15px 17px`, мета — `Folder` (проект), `MapPin` (локация), `ListChecks` («N Punkte»); справа пилюля приоритета и кнопка удаления.

Строка правила: без цветной полосы, иконка `Repeat` `16px` + название шаблона `15px/700`, справа кнопка удаления. Мета-строка: частота жирным `12.5px --text` («Täglich (werktags)», «Wöchentlich: Freitag», «Monatlich: am 1.»); «Nächste Ausführung: <дата>» — дата моно `12px/600 --text`; справа тумблер «Aktiv» — трек `34×20`, `radius 999`, `padding 2px`, ручка `16px` белая; включённый трек `--text`, выключенный `--border`. Неактивное правило: вся строка `background --surface-2`, рамка `#e9e9ec`, `opacity .72`, текст мета `--text-3`.

Пустые состояния: `dict.templates.empty`, `dict.recurring.empty`, `dict.recurring.noTemplatesHint`.

### 5. Analytik — `4d` — `analytics/page.tsx`, `AnalyticsStats.tsx`, `CumulativeFlowChart`, `EstimateAccuracyTable`

Шапка страницы: заголовок + подзаголовок; справа — переключатель периода (сегменты `7 Tage / 30 Tage / 90 Tage`: группа `padding 3px`, `radius 8`, фон `#ececed`; активный — белый, `radius 6`, `--shadow-1`, `12.5px/600`) и кнопки `CSV` / `XLSX`.

**Блок 1 — люди.** Белая карточка `radius 12`, `padding 20px 22px`. Сверху слева «Verfügbar im Zeitraum: <моно 13px/700>», справа моно-подпись `10px` uppercase. Далее grid `1fr 1fr`, `gap 14px 40px`; каждая строка: имя `13.5px/600` + значение моно `13.5px/700` вправо; полоса `height 8px`, `radius 999`, трек `#ececed`, заполнение `--text`; подпись `11.5px/600` моно `--text-2`. **Перегруз (>100%)**: заполнение на 100% и цвет `--brand`, подпись тоже `--brand`. Ноль часов: имя и цифры `--text-3`/`--text-4`, полоса пустая.

**Блок 2 — Aufgaben nach Status im Zeitverlauf.** Заголовок + подзаголовок слева, легенда справа (квадрат `9px`, `radius 3` + подпись `12px --text-2` для каждого из четырёх статусов). График: `display: flex`, `height 212px`, `gap 10px`, снизу линия `1px solid #e9e9ec`; каждый день — колонка `flex: 1`, `flex-direction: column`, `justify-content: flex-end`, `gap 2px`, сегменты сверху вниз: `waiting` (верхний сегмент с `radius 4px 4px 0 0`), `in_progress`, `paused`, `done`. Под графиком — подписи дат моно `10.5px --text-3`, каждая `flex: 1`, по центру. Реализовать как `<div>`-стек (без библиотек), высоты сегментов = количество задач × масштаб.

**Блок 3 — Schätzgenauigkeit.** Grid `1.4fr .6fr 3fr .9fr`. Шапка моно-подписями. Строка: имя `13.5px/600`; число задач моно `12.5px/600` вправо; «распределение вокруг оценки» — дорожка `height 10px` с осью `2px #f2f2f4`, вертикальной риской `1px #d4d4d8` по центру (= 1,0×) и полосой `8px`, `radius 999`, растущей вправо при перерасходе и влево при экономии; справа коэффициент моно `13px/700`. Цвета: `#16a34a` около 1,0, `--brand` при существенном перерасходе, `#2563eb` при недооценке (быстрее оценки). Формат числа — немецкая запятая: `1,38 ×`.

### 6. Admin — `4e` — `admin/page.tsx`, `WipLimitsForm.tsx`, `ResetPasswordForm.tsx`, `DeleteUserButton.tsx`

Контент ограничен `1080px`.

**WIP-Limits** — белая карточка `radius 12`, `padding 20px 22px`. Заголовок + подзаголовок. Далее строка из четырёх полей `flex: 1` + кнопка «Speichern» (тёмная, `padding 11px 18px`): у каждого поля лейбл `12.5px/600` с цветной точкой статуса `8px`, инпут моно `14px/600`, `padding 10px 12px`, `radius 8`; поле в фокусе — рамка `--text` + `0 0 0 3px rgba(24,24,27,.08)`; пустое значение показывает «kein Limit» цветом `--text-4` обычным шрифтом. Под формой — предупреждение при достигнутом лимите: `12px --brand`, фон `--brand-tint`, рамка `--brand-border`, `radius 8`, `padding 9px 12px`, иконка `TriangleAlert` `14px`, текст `dict.wipLimits.errors.limitReached` / «<Spalte> ist aktuell voll — N von N Aufgaben.»

**Benutzer** — заголовок «Benutzer» + счётчик аккаунтов моно `11.5px --text-3`. Строки (`.admin-row`): белая карточка `radius 12`, рамка, `--shadow-1`, `padding 14px 18px`, `display: flex`, `gap 16px`, `align-items: center`. Слева: аватар-круг `32px` (инициалы `11px/700`; у текущего пользователя фон `--text` + белый текст, у остальных — приглушённые пастельные фоны), имя `14px/600`, `@username` моно `12px --text-3`, пилюля роли (Admin — `#fef2f2` / `--brand-ink`; Editor — `#eef2ff` / `#4338ca`), у себя дополнительно серая пилюля «Sie». Справа: инпут «Neues Passwort» (`width 170`, `12.5px`), кнопка «Passwort zurücksetzen» (белая в рамке `#d4d4d8`; при заполненном пароле — тёмная активная), иконочная кнопка удаления `34×34` с иконкой `Trash2` цветом `--brand` — **у своей строки её нет**.

### 7. Ранее согласованные экраны (turn 2 / turn 3)

Реализуются так же, как выше; подробности — в макете:
- **2a / 2b / 2c** — борд: три колонки `1fr`, `radius 12`, фон колонки `rgba(255,255,255,.6)`, рамка `#e9e9ec`, `min-height 470px`, шапка колонки с точкой статуса, названием `13.5px/700` и счётчиком `N/M` (при достигнутом лимите счётчик краснеет: фон `--brand-tint`, рамка `--brand-border`); панель фильтров с чипами и переключателем видов Kanban/Tabelle/Kalender; мобильная версия — одна колонка и горизонтальные табы статусов (тач-таргеты ≥ 44px).
- **3a** — три плотности карточки задачи (kompakt / normal / erweitert): состав полей только из существующей схемы (иконка, стек аватаров, этикетки, прогресс чек-листа, превью комментария, счётчик пауз и «Pausiert von», факт/оценка полосой, наблюдатели).
- **3b** — `SlideOver` + `TaskDetailPanel`: чек-лист, комментарии с @-упоминаниями и подсказками, «Verlauf», кнопки «beobachten» и «Als Vorlage speichern».
- **3c** — «Neue Aufgabe» в две колонки: смысл слева (заголовок, описание, исполнители, этикетки, локация), параметры справа (проект, приоритет, срок, пресеты оценки).

## Interactions & Behavior

Поведение остаётся текущим; визуально добавляется:

- **Hover** карточек и строк: `transform: translateY(-1px)` + переход `--shadow-1` → `--shadow-2`, `transition: box-shadow .18s ease, transform .18s ease`.
- **Hover** иконочных кнопок: фон `--surface-3`, цвет иконки `--text`.
- **Hover** вкладок: цвет `--text`, фон `--surface-3` (активная не меняется).
- **Фокус** любого инпута/селекта: рамка `--text` + `0 0 0 3px rgba(24,24,27,.08)`, без `outline`.
- **Pending-состояние** (серверный экшен в полёте, `.task-card-pending`): `opacity .6`, `pointer-events: none`.
- **Появление строк**: существующая анимация `.page-fade` / `animationDelay: i * 30ms` сохраняется.
- **Тумблер «Aktiv»**: ручка сдвигается `transform: translateX(14px)`, `transition .16s ease`.
- Вне рабочих часов кнопки статуса блокируются с подписью `dict.taskCard.outsideWorkHours` (курсив `11.5px --text-3`).
- Респонсив: `< 1200px` — борд в две колонки; `< 900px` — одна колонка, таблица архива переключается на существующий `.archive-cards`; шапка сжимается (поиск и имя пользователя скрываются, остаются иконки).

## State Management

Новых состояний не требуется. Всё, что показано, уже существует: фильтры в URL-параметрах (`parseTaskFilters`), период аналитики в `?days=`, локаль/тема в профиле, серверные экшены для мутаций, `useTransition` для pending. Открытие панели задачи/проекта — существующий локальный стейт `SlideOver`.

## Assets

- **Шрифт**: Archivo — Google Fonts (`400;500;600;700`).
- **Иконки**: только `lucide-react`, `strokeWidth={1.75}` (в логотипе — `2.25`, в plus-иконке кнопок — `2`). Используются: `Radar`(логотип), `Search`, `Bell`, `Moon`, `ChevronDown/Right`, `Download`, `Pause`, `Play`, `Trash2`, `Pencil`, `MapPin`, `User`, `Users`, `Folder`, `FolderKanban`, `ListChecks`, `Repeat`, `LayoutTemplate`, `Calendar`, `CalendarClock`, `TriangleAlert`, `SearchX`, `Archive`, `Server`, `Truck`, `FileText`, `Wrench`.
- Растровых ассетов нет. Аватары — инициалы на цветном фоне.
- Логотип-«радар» в макете нарисован SVG (два круга + луч); если есть официальный логотип TL-Radar — использовать его.

## Files

| Файл | Что внутри |
| --- | --- |
| `TL-Radar Redesign.dc.html` | все макеты; открывается в браузере, turn 4 — новые вкладки, turn 3/2 — карточки, панель, форма, борд |
| `tokens.css` | готовые CSS-переменные, базовые классы и утилиты для переноса в `app/globals.css` |
| `github.md` | привязка к репозиторию и карта «экран → файлы кода» |

## Порядок внедрения (рекомендация)

1. Подключить Archivo, перенести переменные и тени из `tokens.css`, включить `tabular-nums` для `.mono` — даёт основную часть эффекта без правки компонентов.
2. Шапка: `layout.tsx` + `TopTabs.tsx`.
3. Борд: `TaskCard.tsx` и колонки `KanbanBoard.tsx`.
4. Списковые экраны: `project-row` (проекты + шаблоны + правила), затем `archive-table`.
5. Аналитика (три блока) и Admin.
6. Тёмная тема и мобильные брейкпоинты.
